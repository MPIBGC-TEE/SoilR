continiousRunner.sh sall.R /tmp/ "../../R/*.R  ./runit*.R ./protected/runit*.R ./sall.R"
