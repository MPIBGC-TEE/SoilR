continiousRunner.sh Rtest.R /tmp/tmp2 "$sR/*.R ./runit*.R Rtest.R ./protected/runit*.R"
