 makelink <-function(genericName){
         "\\section{Methods}{
         \\code{\\link{ConstLinDecompOp,matrix-method}} \\cr
         \\code{\\link{ConstLinDecompOp,matrix-method}}
 }"
 }
