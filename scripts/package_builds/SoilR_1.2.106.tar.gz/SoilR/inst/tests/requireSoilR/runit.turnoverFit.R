test.turnoverFit=function(){
     # Calculate the turnover time for a sample from a temperate soil

     turnoverFit(obsC14=40, obsyr=2015, yr0=1850.5, Fatm=Graven2017[,1:2], 
                  plot=FALSE)
     
}
