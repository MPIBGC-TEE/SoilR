#' example.ConstlinDecompOpFromMatrix
#' 
#' An example used in tests and other examples.
#' 
#' 
example.ConstlinDecompOpFromMatrix <-  function(){
	ConstLinDecompOp(matrix(nrow=2,byrow=TRUE,c(-0.1,0,0,-0.2)))
}
