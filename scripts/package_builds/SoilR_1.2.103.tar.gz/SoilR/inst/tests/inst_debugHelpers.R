#!/usr/bin/env Rscript
require('devtools')
devtools::install('../../../../debugHelpers/pkg')
