test.turnoverFit=function(){
     # Calculate the turnover time for a sample from a temperate forest soil

     turnoverFit(obsC14=115.22, obsyr=2004.5, C0=2800, yr0=1900,
                               In=473, Zone="NHZone2")
     
}
