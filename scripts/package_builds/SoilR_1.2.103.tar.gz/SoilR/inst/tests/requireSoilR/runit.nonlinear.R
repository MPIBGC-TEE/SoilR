##
## vim:set ff=unix expandtab ts=2 sw=2:
#require(RUnit)
#test.GeneralNlModel=function(){
#  attr(GeneralNlModel,"ex")()
#}
#
#test.TwopMMmodel=function(){
#attr(TwopMMmodel,"ex")()
#}
#
#test.bacwaveModel=function(){
#attr(bacwaveModel,"ex")()
#}
