#setClass(
#   Class="NonAutonomousLinearModel",
#   contains=c("Model")
#   #validity=correctnessOfModel 
#)
