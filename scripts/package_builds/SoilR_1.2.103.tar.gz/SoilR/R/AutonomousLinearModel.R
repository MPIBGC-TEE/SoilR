#setClass(
#   Class="AutonomousLinearModel",
#   contains=c("Model")
#   #validity=correctnessOfModel 
#)
