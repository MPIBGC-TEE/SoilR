setOldClass('matrix')
setOldClass('list')
setOldClass('function')
